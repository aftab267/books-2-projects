-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 02, 2022 at 02:55 AM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 7.3.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `prime_info`
--

-- --------------------------------------------------------

--
-- Table structure for table `general_info`
--

CREATE TABLE `general_info` (
  `emp_id` int(10) NOT NULL,
  `emp_name` varchar(255) NOT NULL,
  `father_name` varchar(255) NOT NULL,
  `mother_name` varchar(255) NOT NULL,
  `birthday` date NOT NULL,
  `gender` varchar(255) NOT NULL,
  `religion` varchar(255) NOT NULL,
  `marital_status` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `general_info`
--

INSERT INTO `general_info` (`emp_id`, `emp_name`, `father_name`, `mother_name`, `birthday`, `gender`, `religion`, `marital_status`, `mobile`, `email`) VALUES
(5, 'aftab1', 'kazi aftab', 'susmita', '2021-08-01', 'male', 'Islam', 'married', '01711241125', 'aftab267@gmail.com'),
(6, 'rokeya Akter', 'kazi aftab', 'susmita', '2021-08-07', 'male', 'Islam', 'married', '01711241125', 'aftab267@gmail.com'),
(7, 'rokeya Akter', 'kazi aftab', 'susmita', '2021-08-07', 'male', 'Islam', 'married', '01711241125', 'aftab267@gmail.com'),
(8, 'rokeya Akter', 'kazi aftab', 'susmita', '2021-08-07', 'male', 'Islam', 'Unmarried', '01711241125', 'aftab267@gmail.com'),
(9, 'sanowar', 'kazi aftab', 'susmita', '2007-02-09', 'male', 'Hindu', 'married', '01711241125', 'aftab267@gmail.com'),
(12, 'a', 'kazi aftab', 'susmita', '2021-08-12', 'on', 'Islam', 'married', '01711241125', 'aftab267@gmail.com'),
(14, 'ggg', 'ggg', 'ggg', '2021-08-27', 'male', 'Islam', 'married', '01711241125', 'aftab267@gmail.com'),
(15, 'sssss', 'sss', 'sss', '2021-08-06', 'on', 'Islam', 'married', '01711241125', 'aftab267@gmail.com'),
(17, 'rokeya Akter', 'ggg', 'susmita', '2021-08-04', 'on', 'Islam', 'married', '01711241125', 'aftab267@gmail.com'),
(19, 'a', 'kazi aftab', 'susmita', '2021-08-13', 'female', 'Islam', 'married', '01711241125', 'aftab267@gmail.com'),
(20, 'Kazi Aftabur Rahman', 'kazi aftab', 'susmita', '2021-08-04', 'male', 'Islam', 'married', '01711254487', 'jasim_moni10@yahoo.com'),
(21, 'aftab', 'kazi aftab', 'susmita', '0000-00-00', 'female', 'Islam', 'married', '01789457845', 'sakil@gmail.com'),
(22, 'a', 'kazi aftab', 'susmita', '2021-08-06', 'female', 'Hindu', 'Unmarried', '01711254487', 'jasim_moni10@yahoo.com'),
(23, 'a', 'kazi aftab', 'susmita', '2021-08-05', 'male', 'Buddihs', 'married', '01711241125', 'aftab267@gmail.com'),
(24, 'a', 'kazi aftab', 'susmita', '2021-08-05', 'male', 'Buddihs', 'married', '01711241125', 'aftab267@gmail.com'),
(25, 'a', 'kazi aftab', 'susmita', '2021-08-05', 'male', 'Buddihs', 'married', '01711241125', 'aftab267@gmail.com'),
(26, 'sovon', 'Nozrul Islam ', 'monowara begun', '2021-08-20', 'male', 'Islam', 'married', '01711254487', 'tajmahalcl0002@gmail.com'),
(27, 'aftab', 'kazi mostafiz', 'Awlia begum', '2022-01-05', 'male', 'Islam', 'married', '01711241125', 'admin@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `emp_id` int(10) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `status` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`emp_id`, `full_name`, `email`, `mobile`, `password`, `status`) VALUES
(8, 'Kazi Aftabur rahman', 'aftab267@gmail.com', '01711241125', 'aftab123456', 2),
(9, 'Momin', 'tajmahalcl0002@gmail.com', '01711254487', '123', 2),
(12, 'kazi', 'kaziaftabur@gmail.com', '01711254487', '123', 1),
(13, 'Shovon', 'sovon@gmail.com', '01711254487', '123', 1),
(14, 'kazi', 'a@gmail.com', '01711241125', '123', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `general_info`
--
ALTER TABLE `general_info`
  ADD PRIMARY KEY (`emp_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`emp_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `general_info`
--
ALTER TABLE `general_info`
  MODIFY `emp_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `emp_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
